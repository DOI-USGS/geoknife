rGDP
=====

R tools for accessing processing features of the USGS's Geo Data Portal (GDP). See cida.usgs.gov/gdp for a web interface for the GDP. 

install this package using "
