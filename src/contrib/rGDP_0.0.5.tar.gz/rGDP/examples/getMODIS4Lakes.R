library("rGDP")

# ---- variables -----
WFS <-  'https://www.sciencebase.gov/catalogMaps/mapping/ows/51b0f5e5e4b030b51983cda1'
feature_collection  <-	'sb:WBIC_190900'
attribute  <-	'WBDY_WBIC'
datasetURI	<-	'dods://opendap-dev.cr.usgs.gov:8080/opendap/MCD12C1.051.ncml'
var	<-	'CMG_0_05_Deg_16_days_NDVI'
# ---- variables -----

# instantiate rGDP object	
rGDP	<-	rGDP()
# feature weighted grid stats
rGDP	<-	setAlgorithm(rGDP,getAlgorithms(rGDP)[4])

# show what 'cha got
print(rGDP)

# set the web feature service
rGDP	<-	setWFS(rGDP,WFS)

# set the feature collection for the element in the service that you want to use
rGDP	<-	setFeature(rGDP,list('FEATURE_COLLECTION'=feature_collection,
	'ATTRIBUTE'=attribute))
	
# set the process inputs that you want to use
rGDP	<-	setPostInputs(rGDP,list('DATASET_ID'=var,
								'DATASET_URI'=datasetURI,
                                'STATISTICS'='MAXIMUM'))

# show what 'cha got
print(rGDP)

# execute what you have
rGDP	<-	executePost(rGDP)

status.rGDP  <-  checkProcess(rGDP)

cat('checking status of GDP request. Large complex requests take longer to process.\n')
repeat{
	if (!is.null(status.rGDP$URL) | status.rGDP$status!=""){
	    break
	  }
  cat('checking process...\n')
  Sys.sleep(10)
  if (is.null(status.rGDP$URL)){
    status.rGDP  <-  checkProcess(rGDP)
  }
}

if (status.rGDP$status=='Process successful'){
	cat(paste(status.rGDP$status,'\nDownload available at: ',status.rGDP$URL,sep=''))
} else {
	cat(status.rGDP$status)
}
